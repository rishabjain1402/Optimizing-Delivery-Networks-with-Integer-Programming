The data includes the following:
1. customer_location.csv: the locations for each customer
2. warehouse_location.csv: the locations for each warehouse
3. supply.csv: the number of supply for each warehouse
4. driver_location.csv: the locations for the driver's home (for the bonus question)